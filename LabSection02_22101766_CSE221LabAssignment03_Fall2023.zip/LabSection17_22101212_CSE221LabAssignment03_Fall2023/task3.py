f = open('input3.txt', 'r')
f_out = open('output3.txt', 'w')
n = f.readline().strip()
A = [int(i) for i in f.read().split(" ")]
c = 0

def merge(n, m, A, B):
    i, j, k = 0, 0, 0
    C = (n+m)*[0]
    global c

    while i<n and j<m:
        if A[i]<B[j]:
            C[k] = A[i]
            i += 1
        else:
            C[k] = B[j]

            c += 1
            j += 1
            c += len(A[i+1:])

        k += 1

    if i!=n:
        for i in A[i:]:
            C[k] = i
            k += 1

    if j!=m:
        for i in B[j:]:
            C[k] = i
            k += 1

    return C


def mergeSort(arr):
    if len(arr) <= 1:
        return arr
    else:
        mid = len(arr)//2
        a1 = mergeSort(arr[:mid])
        a2 = mergeSort(arr[mid:])
        return merge(len(a1), len(a2), a1, a2)

mergeSort(A)
f_out.write(str(c))
print(c)
