def merge(a, b):
    n = len(a)
    m = len(b)
    C = (n+m)*[0]
    i, j, k = 0, 0, 0
    while i<n and j<m:
        if a[i]<=b[j]:
            C[k] = a[i]
            i += 1
        else:
            C[k] = b[j]
            j += 1
        k += 1
    if i!=n:
        for i in a[i:]:
            C[k] = i
            k += 1
    if j!=m:
        for i in b[j:]:
            C[k] = i
            k += 1
    return C
def mergeSort(arr):
    if len(arr) <= 1:
        return arr
    else:
        mid = len(arr)//2
        a1 = mergeSort(arr[:mid])  # write the parameter 
        a2 = mergeSort(arr[mid:])  # write the parameter
        return merge(a1, a2)          # complete the merge function above 
f1 = open("input1.txt", "r")
f2 = open("output1.txt", "w")
inp = f1.read().split("\n")
f1.close()
arr = inp[1].split(" ")
arr = list(map(int, arr))
sorted = list(map(str, mergeSort(arr)))
f2.write(" ".join(sorted))
f2.close()
