f = open('input5.txt', 'r')
f_out = open('output5.txt', 'w')
n = int(f.readline().strip())
A = [int(i) for i in f.read().strip().split(" ")]

def partition(A, l, r):
	x = A[r]
	i = l-1
	j = l
	while j<=r-1:
		if A[j]>=x:
			i += 1
			A[i], A[j] = A[j], A[i]
		j+=1

	A[i+1], A[r] = A[r], A[i+1]

	return i+1

def quicksort(A, l, r):
	if l<r:
		q = partition(A, l, r)
		quicksort(A, l, q-1)
		quicksort(A, q+1, r)

quicksort(A, 0, n-1)
print(A)
