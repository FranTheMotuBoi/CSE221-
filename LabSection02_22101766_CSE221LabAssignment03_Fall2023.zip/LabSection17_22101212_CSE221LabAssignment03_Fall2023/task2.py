def find_max(arr):
	if len(arr)==1:
		return arr
	else:
		mid = len(arr)//2
		a = find_max(arr[:mid])
		b = find_max(arr[mid:])
  
		if a[0]>=b[0]:
			return a
		else:
			return b

file1 = open("input2.txt", "r")
file2 = open("output2.txt", "w")
inp = int(file1.readline().strip())

arr = [int (i) for i in file1.readline().strip().split(" ")]

file2.write(str(find_max(arr)[0]))
file2.close()