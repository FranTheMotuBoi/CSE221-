f = open('input4.txt', 'r')
f_out = open('output4.txt', 'w')
n = int(f.readline().strip())
A = [int(i) for i in f.read().strip().split(" ")]

def find_max_pair(n, A):
    i , j = 0, n-1
    k = j
    maxx_i = A[0]
    maxx_j_sq = A[n-1]**2
    while i<k:
        if A[j]**2>maxx_j_sq:
            maxx_j_sq = A[j]**2
            k = j

        if A[i]>maxx_i:
            maxx_i = A[i]

        i += 1
        j -= 1

    return (maxx_i+maxx_j_sq)

f_out.write(str(find_max_pair(n, A)))
