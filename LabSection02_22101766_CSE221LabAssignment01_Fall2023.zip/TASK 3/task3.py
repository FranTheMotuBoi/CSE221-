f = open('input3.txt', 'r')
f_out = open('output3.txt', 'w')
n = int(f.readline().strip())
ids = [int(i) for i in f.readline().strip().split(" ")]
marks = [int(i) for i in f.readline().strip().split(" ")]

def sort_marks(n, ids, marks):
    for i in range(n-1):
        idx = i

        for j in range(i, n):
            if marks[j]>marks[idx] or (marks[j]==marks[idx] and ids[j]<ids[idx]):
                idx = j

        marks[i], marks[idx] = marks[idx], marks[i]
        ids[i], ids[idx] = ids[idx], ids[i]


sort_marks(n, ids, marks)

for i in range(n):
	f_out.write(f"ID: {ids[i]} Mark: {marks[i]}\n")