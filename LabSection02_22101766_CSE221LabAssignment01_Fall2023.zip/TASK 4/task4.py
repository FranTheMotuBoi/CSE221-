class Trains:
	all_trains = []
	def __init__(self, name, station, time):
		self.name = name
		self.station = station
		self.hour =  int(time.split(":")[0])
		self.minute =  int(time.split(":")[1])
	
	def __lt__(self, other):
		if self.name<other.name:
			return True
		else:
			return False

	def __eq__(self, other):
		if self.name==other.name:
			return True
		else:
			return False


f = open('input4.txt', 'r')
f_out = open('output4.txt', 'w')
n = int(f.readline().strip())
trains = [i.split(" will departure for ") for i in f.read().split("\n")]
for i in trains:
	Trains.all_trains.append(Trains(i[0], i[1].split(" at ")[0], i[1].split(" at ")[1]))


def sort_trains(n, t_array):
	for i in range(1, n):
	    
	    temp = t_array[i]
	    j = i-1

	    while j >= 0 and (temp < t_array[j] or (temp==t_array[j] and \
	    	(temp.hour>t_array[j].hour or temp.hour==t_array[j].hour and temp.minute>t_array[j].minute))):
	            
	            t_array[j + 1] = t_array[j]
	            j -= 1

	    t_array[j + 1] = temp

sort_trains(n, Trains.all_trains)


for i in Trains.all_trains:
	if i.hour<10:
		i.hour = "0"+str(i.hour)

	if i.minute<10:
		i.minute = "0"+str(i.minute)

	f_out.write(f"{i.name} will departure for {i.station} at {i.hour}:{i.minute}\n")