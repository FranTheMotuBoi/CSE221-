f = open("Task 01/part a/input1a_2.txt", 'r')
task1a_output = open("Task 01/part a/output1a_2.txt", "w")
v, e = [int(i) for i in f.readline().strip().split(" ")]
adj = [[0 for i in range(v+1)] for i in range(v+1)]

for i in range(e):
    x, y, z = [int(j) for j in f.readline().strip().split(" ")]
    adj[x][y] = z

for row in adj:
    elem_row = ""
    for element in row:
        elem_row = elem_row + " " + str(element)
    elem_row = elem_row + "\n"
    task1a_output.write(elem_row)

task1a_output.close()