f = open("Task 01/part b/input1b_3.txt", 'r')
f_output = open("Task 01/part b/output1b_3.txt", "w")
v, e = [int(i) for i in f.readline().strip().split(" ")]

adj = {}
for i in range(v+1):
    adj[i] = []

for i in range(e):
    x, y, z = [int(i) for i in f.readline().strip().split()]
    adj[x].append((y, z))

for i, j in adj.items():
    if j:
        f_output.write(f"{i}: ")
        for k in j:
        	f_output.write(str(k) + " ")
        f_output.write("\n")
    else:
        f_output.write(f"{i}: \n")
