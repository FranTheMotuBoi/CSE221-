from collections import deque
q = deque()
f = open("Task 02/input2_4.txt", 'r')
f_output = open("Task 02/output2_4.txt", "w")
v, e = [int(i) for i in f.readline().strip().split(" ")]

adj = {}
for i in range(v+1):
    adj[i] = []

for i in range(e):
    lst2 = f.readline().strip().split()
    x = int(lst2[0])
    y = int(lst2[1])
    adj[x].append(y)
    adj[y].append(x)
f.close()
visited = (v+1)*[False]

visited[1] = True
path = []
q.append(1)
path.append(1)
while len(q)!=0:
    u = q.popleft()
    for i in adj[u]:
        if visited[i]==False:
            visited[i] = True
            path.append(i)
            q.append(i)


for i in path:
    f_output.write(str(i) + " ")
