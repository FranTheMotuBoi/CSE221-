f = open("Task 03/input3_4.txt", 'r')
f_output = open("Task 03/output3_1.txt", "w")
v, e = [int(i) for i in f.readline().strip().split(" ")]

adj = {}
for i in range(v+1):
    adj[i] = []

for i in range(e):
    lst2 = f.readline().strip().split()
    x = int(lst2[0])
    y = int(lst2[1])
    adj[x].append(y)
    adj[y].append(x)
f.close()
visited = (v+1)*[False]

def dfs(G, u=1):
	visited[u] = True
	print(u, end=" ")
	for i in G[u]:
		if not visited[i]:
			dfs(G, i)

dfs(adj)