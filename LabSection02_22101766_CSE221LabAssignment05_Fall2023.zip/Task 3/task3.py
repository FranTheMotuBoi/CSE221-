f = open("input3_3.txt", "r")
f_out = open("output3_3.txt", "w")
n, m = [int(i) for i in f.readline().strip().split(" ")]

adj = {}

for i in range(n+1):
    adj[i] = []

for i in range(m):
    lst = f.readline().strip().split()
    x = int(lst[0])
    y = int(lst[1])

    adj[x].append(y)
f.close()

white = -1
grey = 0
black = 1

def create_transpose(adj):
    temp = {}
    for k in adj:
        temp[k] = []
    
    for i, j in adj.items():
        for l in j:
            temp[l].append(i)

    return temp


def dfs(G, color, path, st, output=False):
    global white
    global grey
    global black

    color[st] = grey
    if output:
        f_out.write(str(st) + " ")

    for i in G[st]:
        if color[i]==grey:
            break
        elif color[i]==white:
            dfs(G, color, path, i, output)
    color[st] = black
    path.append(st)


#Getting the first dfs stack
color_1 = [white for i in range(n+1)]
first_stack = []
for j in range(1, n+1):
    if color_1[j]==white:
        dfs(adj, color_1, first_stack, j)

#Transposing and getting the second dfs path by using the first stack
transpose = create_transpose(adj)
first_stack = first_stack[::-1]
final_path = []
color_2 = [white for i in range(len(first_stack)+1)]
for i in first_stack:
    if color_2[i]==white:
        dfs(transpose, color_2, final_path, i, True)
        f_out.write("\n")
