from queue import PriorityQueue
f = open("input2_3.txt", "r")
f_out = open("output2_3.txt", "w")
n, m = [int(i) for i in f.readline().strip().split(" ")]
q = PriorityQueue()

adj = {}
for i in range(n+1):
    adj[i] = []

for i in range(m):
    lst = f.readline().strip().split()
    x = int(lst[0])
    y = int(lst[1])

    adj[x].append(y)
f.close()

doables = [0 for i in range(n+1)]
visited = [False for i in range(n+1)]
ans = ""

for i in adj:
	for j in adj[i]:
		doables[j] += 1


def check_doables(adj):
	for i in range(1, len(doables)):
		if doables[i]==0 and not visited[i]:
			q.put(i)
			visited[i] = True


	if q.qsize()==0:
		return False
	else:
		return True


def bfs(adj):
	global ans
	global m	
	if check_doables(adj):
		while q.qsize()>0:
			temp = q.get()
			ans += str(temp) + " "
			for j in adj[temp]:
				doables[j] -= 1
				m -= 1
			check_doables(adj)

	
bfs(adj)

if m!=0:
	f_out.write("Impossible")
else:
	f_out.write(ans)