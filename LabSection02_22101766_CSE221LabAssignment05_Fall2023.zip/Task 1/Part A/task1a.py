f = open("input1_3.txt", "r")
f_out = open("output1_3.txt", "w")
n, m = [int(i) for i in f.readline().strip().split(" ")]

adj = {}
for i in range(n+1):
    adj[i] = []

for i in range(m):
    lst = f.readline().strip().split()
    x = int(lst[0])
    y = int(lst[1])

    adj[x].append(y)
f.close()

white = -1
grey = 0
black = 1
color = [white for i in range(n+1)]
new = []
temp = False

def dfs(adj, st):
    global white
    global grey
    global black
    global color
    global temp
    color[st] = grey
    for i in adj[st]:
        if color[i]==grey:
            temp = True
            return False
        elif color[i]==white:
            dfs(adj, i)
    color[st] = black
    global new
    new.append(st)

for j in range(1, n+1):
    if not temp:
        if -1==color[j]:
            dfs(adj, j)
    else:
        break

if temp:
    print("IMPOSSIBLE")
    f_out.write("IMPOSSIBLE")
else:
    print(new[::-1])
    for i in range(n-1, -1, -1):
        f_out.write(f"{new[i]}, ")
