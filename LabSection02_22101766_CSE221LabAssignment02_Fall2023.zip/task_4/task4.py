from queue import PriorityQueue
q = PriorityQueue()

def calculate_tasks(tasks, p):
	last = [0]*p
	for i in tasks:
		q.put((i[1], i[0]))
	j = 0
	while q.qsize()>0:
		u = q.get()
		diff = float('inf')
		diff_i = -1
		for i in range(len(last)):
			if u[1]>=last[i]:
				if (u[1] - last[i])<diff:
					diff = u[1] - last[i]
					diff_i = i

		if diff_i!=-1:
			last[diff_i] = u[0]
			j += 1

	return j

def get_tasks(input_data, output_data):
	f = open(input_data, 'r')
	f_output = open(output_data, 'w')
	n, p = [int(i) for i in f.readline().strip().split()]
	
	items = []
	for i in range(n):
		items.append([int(i) for i in f.readline().strip().split()])

	f_output.write(str(calculate_tasks(items, p)))


get_tasks('input2_1.txt', 'output2_1.txt')
get_tasks('input2_2.txt', 'output2_2.txt')
get_tasks('input2_3.txt', 'output2_3.txt')
get_tasks('input2_4.txt', 'output2_4.txt')