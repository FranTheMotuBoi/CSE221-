inp=open('input2.txt','r')
out=open('output2.txt','w')
t1=inp.readline().strip()
arr1=inp.readline().strip().split(' ')

t2=inp.readline().strip()
arr2=inp.readline().strip().split(' ')

i=0
j=0
new_arr=[]
while i<len(arr1) and j<len(arr2):
        if int(arr1[i]) < int(arr2[j]):
            new_arr.append(int(arr1[i]))
            i+=1
        else:
             new_arr.append(int(arr2[j]))
             j+=1

while i<len(arr1):
    new_arr.append(int(arr1[i]))
    i+=1
while j<len(arr2):
    new_arr.append(int(arr2[j]))
    j+=1
out.write(f'{new_arr}')


inp.close()
out.close()