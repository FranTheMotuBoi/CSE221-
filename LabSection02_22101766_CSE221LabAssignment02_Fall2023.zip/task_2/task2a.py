
def merge(a, b):
    new = []
    i = 0
    j = 0
    while i<len(a) and j<len(b):
        if a[i] < b[j]:
            new.append(a[i])
            i += 1
        else:
            new.append(b[j])
            j += 1
    while i < len(a):
        new.append(a[i])
        i += 1
    while j < len(b):
        new.append(b[j])
        j += 1
    return new

def mergeSort(arr):
    if len(arr) <= 1:
        return arr
    else:
        mid = len(arr)//2
        a1 = mergeSort(arr[mid:])
        a2 = mergeSort(arr[:mid])
        return merge(a1, a2)

infile=open('input2.txt','r')
outfile=open('output2.txt','w')

lis = infile.readlines()
l1 = lis[1].strip(" \n")
l2 = lis[3].strip(" \n")
a = list(map(int, l1.split(" ")))
b = list(map(int, l2.split(" ")))
arr = a + b
new = mergeSort(arr)
ln = ""
for i in range(len(new)-1):
    ln += str(new[i]) + " "
ln += str(new[len(new)-1])
outfile.writelines(ln)