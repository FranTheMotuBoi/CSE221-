
inp=open('input3.txt','r')
out=open('output3.txt','w')
n=int(inp.readline().strip())
G=[]

for a in range(n):
    s,e=inp.readline().strip().split(' ')
    s,e=int(s),int(e)
    G.append((s, e))

G.sort(key=lambda x:x[1])

task=[]
count=0
start=-1

for i in range(len(G)):
    if G[i][0]>=start:
        count+=1
        task.append(G[i])
        start=G[i][1]

out.write(f'{count}\n')
for x in range(len(task)):
    out.write(f'{task[x][0]} {task[x][1]} \n')

inp.close()
out.close()